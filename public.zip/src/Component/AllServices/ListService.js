import React, {useState} from 'react'
import "./ListService.css"
import List_Building_Data_Management from "../../Assets/List-Building-Data-Management.png"
import Footer from '../FooterStop/Footer'
import NavbarMain from '../NavbarUpper/NavbarMain';
function ListService() {
 
    const [hoveredIndex, setHoveredIndex] = useState(null);

    const handleMouseEnter = index => {
      setHoveredIndex(index);
    };
  
    const handleMouseLeave = () => {
      setHoveredIndex(null);
    };
  return (
   <div>
   <NavbarMain/>
   
<div className='container'>
<div className='list_building mt-5 mb-5'>List Building & Data Management
</div>
<div className='row'>
<div className='col-xl-8 col-lg- col-md- col-sm- col-'>
<img className='pt-5' src={List_Building_Data_Management}/>
<div>
<h1 className='ListHeading mt-5'>Turning Prospects into Profits with Precision and Expertise
   </h1>
   <p className='Listsubheading'>In the real of real estate marketing, the power of a well-crafted list cannot be overstated. At StopShopREI, our List Marketing Services are designed to transform your outreach strategy, ensuring every call, email, and message reaches the right audience. As a leading name among media marketing agencies, we specialize in leveraging data to maximize your business impact.
   </p>
</div>
<div>
<h1 className='ListHeading mt-5'>Service Process: Your Path to Effective List Marketing</h1>
<div className='row'>
<div className='col-xl-6 col-lg- col-md- col-sm- col-'>
<div>
<p className='listmarketing_content'><span className='listmarketing_num'>01</span>Comprehensive Analysis</p>
<p className='listmarketing_par'>We start by thoroughly understanding your target market. Our team analyzes market trends, demographic data, and behavioral patterns to create a foundational base for your list building.

</p>
</div>
</div>
<div className='col-xl-6 col-lg- col-md- col-sm- col-'>
<div>
<p className='listmarketing_content'><span className='listmarketing_num'>02</span>Tailored List Creation</p>
<p className='listmarketing_par'>Using our insights from the market analysis, we craft a customized list that aligns with your specific goals. This list is not just data – it's a roadmap to  clients who need what you're offering
</p>
</div>
</div>

<div className='col-xl-6 col-lg- col-md- col-sm- col-'>
<div>
<p className='listmarketing_content'><span className='listmarketing_num'>03</span>Integration with Marketing Channels</p>
<p className='listmarketing_par'>We start by thoroughly understanding your target market. Our team analyzes market trends, demographic data, and behavioral patterns to create a foundational base for your list building.

</p>
</div>
</div>
<div className='col-xl-6 col-lg- col-md- col-sm- col-'>
<div>
<p className='listmarketing_content'><span className='listmarketing_num'>04</span>Cold Calling and Outreach</p>
<p className='listmarketing_par'>With the list in hand, our team, including the best virtual assistants and seasoned marketers, initiates the outreach. We employ cold calling and other direct marketing techniques to engage with your audience effectively.
</p>
</div>
</div>

<div className='col-xl-6 col-lg- col-md- col-sm- col-'>
<div>
<p className='listmarketing_content'><span className='listmarketing_num'>05</span>Continuous Optimization</p>
<p className='listmarketing_par'>List marketing is not a 'set and forget' strategy. We constantly analyze the responses, refine the list, and optimize our approaches to ensure maximum ROI.

</p>
</div>
</div>
<div className='col-xl-6 col-lg- col-md- col-sm- col-'>

</div>
</div>
</div>
</div>
<div className='col-xl-4 col-lg-6 col-md-8 col-sm- col-'>
<div className='Services_list mt-4'>
<div>
<h3 className='service_head m-3'>Services</h3>
<ul className="list">
{
    
["01 List Building & Data Management", 
"02 Text Marketing",
"03 Cold Calling",
"04 Email Marketing",
"05 Digital Marketing",
"06 Ringless Voice Mails",
"07 Follow up Manager",
"08 Acquistion Manager",
"09 Dispostions",
"10 Accounts & Book Keeping",
"11 Post Card Campigns",
"12 Blog and Content Writing"

]
    
    
    
    .map((item, index) => (
  <li
    key={index}
    className={`list-item ${hoveredIndex === index ? 'hovered' : ''} m-3 list_stylecol` }
    onMouseEnter={() => handleMouseEnter(index)}
    onMouseLeave={handleMouseLeave}
    
  >
   {item}
    <span className={`arrow ${hoveredIndex === index ? 'up' : ''}`}>&#x25BC;</span>
  </li>
))}
</ul>
</div>


</div>

</div>
</div>
</div>
<div className='container'>
   <div className='row'>
<div className='col-8'>
   <h1 className='ListHeading'>Service Outcome: Tangible Results, Real Impact
   </h1>
   <p className='Listsubheading'>Our List Marketing Services culminate in tangible outcomes for your real estate business:
   </p>
   <ol>
   <li className='list_style'><span className='list_bold'>Enhanced Lead Generation:</span> By reaching the right audience, our services significantly improve your lead generation efforts.</li>
   <li className='list_style'><span className='list_bold'>Increased Conversion Rates:</span> With targeted outreach, expect higher conversion rates from prospect to client.</li>
   <li className='list_style'><span className='list_bold'>Optimized Marketing Budget:</span> Efficient list utilization means your marketing budget is spent on leads with the highest conversion potential.</li>
   <li className='list_style'><span className='list_bold'>Sustainable Business Growth:</span> Our approach is designed for long-term success, ensuring continual growth in your client base and market presence.</li>
   </ol>
   </div>
   </div>
</div>
   
   
   <Footer/>
   </div>
  )
}

export default ListService
